package globalplatform

import "github.com/ethereum/go-ethereum/log"

var logger = log.New("package", "keycard-go/globalplatform")
