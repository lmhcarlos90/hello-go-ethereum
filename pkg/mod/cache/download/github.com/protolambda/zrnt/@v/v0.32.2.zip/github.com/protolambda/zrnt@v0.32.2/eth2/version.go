package eth2

const VERSION = "v0.32.2"
