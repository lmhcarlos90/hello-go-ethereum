## Smithy Go Private packages ##
`private` is a collection of packages used internally by Smithy Go, and is subject to have breaking changes. This package is not `internal` because it is an implementation detail of generated code.
