// Serves as examples of using the goupnp library.
//
// To run examples and see the output for your local network, run the following
// command (specifically including the -v flag):
//     go test -v github.com/huin/goupnp/example
package example
