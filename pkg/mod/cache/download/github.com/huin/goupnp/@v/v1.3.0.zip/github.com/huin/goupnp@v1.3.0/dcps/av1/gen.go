//go:generate goupnpdcpgen -dcp_name av1 -code_tmpl_file ../dcps.gotemplate
package av1
