# go-minisign

A Golang library to verify [Minisign](https://jedisct1.github.io/minisign/) signatures.

