# Release History

## 1.0.0 (2022-05-16)

### Features Added
* Export FakeCredential

### Other Changes
* Upgrade dependencies of azcore, azidentity and armresources to the stable version

## 0.3.0 (2022-04-08)

### Breaking Changes
* Upgrade to generic version for test helper

## 0.2.0 (2022-03-16)

### Features Added
* Add helper method for ARM template deployment
* Add delegate stop method return for start recording

## 0.1.0 (2022-03-10)

### Features Added
* Add test util for resource manager

