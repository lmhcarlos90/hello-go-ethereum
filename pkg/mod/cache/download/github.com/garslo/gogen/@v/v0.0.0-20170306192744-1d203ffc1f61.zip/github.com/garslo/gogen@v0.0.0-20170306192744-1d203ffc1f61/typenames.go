package gogen

const (
	StringT = "string"
	IntT    = "int"
)
