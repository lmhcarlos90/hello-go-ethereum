package fn

import "github.com/garslo/gogen"

type Functions struct {
	Package *gogen.Package
}
