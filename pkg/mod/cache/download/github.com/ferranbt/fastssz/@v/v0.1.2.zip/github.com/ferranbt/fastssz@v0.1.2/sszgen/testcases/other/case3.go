package other

//go:generate go run ../../main.go --path case3.go

type Case3B struct {
}
