package other2

type Case4Slot uint64
