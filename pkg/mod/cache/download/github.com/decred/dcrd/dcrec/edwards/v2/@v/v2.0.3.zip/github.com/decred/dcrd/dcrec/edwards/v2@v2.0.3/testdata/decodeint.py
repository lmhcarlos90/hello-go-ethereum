import sys
from ed25519 import *

decodeinthex(sys.argv[1])
