// Copyright (c) 2016-2020 The Decred developers
// Use of this source code is governed by an ISC
// license that can be found in the LICENSE file.

/*
Package cpuminer provides facilities for solving blocks (mining) using the CPU.
*/
package cpuminer
