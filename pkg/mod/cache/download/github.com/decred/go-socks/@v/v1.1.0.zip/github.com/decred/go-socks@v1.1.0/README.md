SOCKS5 Proxy Package for Go
===========================

[![Build Status](https://github.com/decred/go-socks/workflows/Build%20and%20Test/badge.svg)](https://github.com/decred/go-socks/actions)
[![BSD License](https://img.shields.io/badge/license-BSD-blue.svg)](http://copyfree.org)
[![GoDoc](https://img.shields.io/badge/godoc-reference-blue.svg)](https://godoc.org/github.com/decred/go-socks)

License
-------

3-clause BSD. See LICENSE file.
