package samename

// The A is used in the parent package as a dependency
type A struct{}
