package one

// Thing is just a thing.
type Thing struct{}
