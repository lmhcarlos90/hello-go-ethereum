package emptyinterface

// Empty is an empty interface
type Empty interface{}
