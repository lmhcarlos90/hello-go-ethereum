function test() {
    return "passed";
}

module.exports = {
    test: test
}
